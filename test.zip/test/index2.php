<!DOCTYPE html>
<head>
<title>Lee Hicks Prop Data Assessment</title>
<meta charset="UTF-8">
<meta name="description" content="Prop Data Assessment">
<meta name="author" content="Lee Hicks">
<meta name="ROBOTS" content="INDEX, NOFOLLOW">
<meta name="viewport" content="width=device-width" />
<link rel="stylesheet/less" type="text/css" href="lee.less" />
<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/2.5.1/less.min.js"></script>
<script src="extensions/jquery-1.8.0.min.js"></script>
</head>
<html lang="en">
<body>
<div id="holdalldivs">

</div>


</body>
</html>
